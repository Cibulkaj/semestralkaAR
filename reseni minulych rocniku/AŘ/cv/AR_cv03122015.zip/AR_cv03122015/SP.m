H10 = .5;
H20 = .3;

syms H1 H2 Sp S2 Q S cp c2 g k1 k2 s
k1 = cp*Sp/S*sqrt(2*g);
k2 = c2*S2/S*sqrt(2*g);
f = [-k1*sqrt(H1-H2)+1/S*Q;
    k1*sqrt(H1-H2)-k2*sqrt(H2)];
x = [H1, H2];
u = Q;
A = jacobian(f,x);
B = diff(f,u);
C = [0 1];

P = C*(inv(s*eye(2)-A))*B;
g = 9.81;
S = 25e-4;
cp = .6;
c2 = .6;

P0 = simplify(P);
P0 = eval(P0);
P0 = collect(P0, s);

H1 = H10;
H2 = H20;
Q = 1.5e-4;
fnum = eval(f);

[S2,Sp] = solve(fnum);
%Sp = eval(solve(fnum(1,1)));
%SP2 = Sp;
%S2 = solve(subs(fnum(2,1), 'Sp', Sp2));
S2 = eval(S2);
Sp = eval(Sp);

P0 = eval(P0);
P0 = collect(P0, s);

w = 10;
subs(P0, s, sqrt(-1)*w);