%%
%Model dmychadla
close all; clear all; clc;
J = .0475;  %kgm^2
m = 1.5;    %kg
r = .25;    %m
g = 9.81;   %m/s^2
d = .1;     
l = .05;    %m

%syms s
% C = 20*(s+25)/(s+300);
% W1 = 10/(s^2 + 2*s + 10);
% S = 1 / (1+P.Nominal*C);
% 
% P = (r + delta*r) / (J*s^2+d*s+m*g*l);
r = ureal('r', .25, 'Percentage', 20);
P = tf(r, [J d m*g*l]);
C = tf([20 20*25], [1 300]);    %nen� robustn� kvalitn�   
%C = tf([20 50*25], [1 300]);   %je robustn� kvalitn� :)
P0 = tf(P.Nominal);

T = P0*C/(1+P0*C);
S = 1/(1+P0*C);
W1 = tf(10, [1 2 10]);
W2 = .2;

omg = logspace(-2,3,1000);       
W1S = W1*S;
FW1S = squeeze(freqresp(W1S, omg));
AFW1S = abs(FW1S);
W2T = W2*T;
FW2T = squeeze(freqresp(W2T, omg));
AFW2T = abs(FW2T);
plot(AFW1S)     %m�lo by ||FW1S||_inf <= 1
figure;
plot(AFW2T)     %taky <= 1
figure
plot(AFW1S+AFW2T)
hold on
plot(ones(1,length(AFW1S)), 'r')


P2 = augw(P,W1,[],W2);
[K,CL,GAM] = hinfsyn(P2);